# MrUnknownTricker

apt update
apt upgrade
apt install git
apt install python
apt install python2
pip2 install requests
pip2 install mechanize
git clone https://github.com/MrSh4dow404/MrUnknownTricker.git
cd MrUnknownTricker
python2 SHADOW.py

USERNAME>>>>>>>> MR
PASSWORD>>>>>>>> UNKNOWN
